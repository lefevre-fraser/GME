﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GmeLib;

namespace GME.CSharp
{
    static class MgaGateway
    {
        public static IMgaProject project;
        public static IMgaTerritory territory;

#region TRANSACTION HANDLING
        public static void BeginTransaction(transactiontype_enum mode = transactiontype_enum.TRANSACTION_GENERAL)
        {
            project.BeginTransaction(territory, mode);
        }

        public static void CommitTransaction()
        {
            project.CommitTransaction();
        }

        public static void AbortTransaction()
        {
            project.AbortTransaction();
        }
#endregion
	public static IMgaMetaBase GetMetaByName(string name)
        {
            try
            {
                return project.RootMeta.RootFolder.get_DefinedFCOByName(name, false) as IMgaMetaFCO;
            }
            catch (System.Runtime.InteropServices.COMException e)
            {
                return project.RootMeta.RootFolder.get_DefinedFolderByName(name, false) as IMgaMetaFolder;
            }
        }



    }
}
