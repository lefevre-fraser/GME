﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;
using GME.CSharp;
using GmeLib;
using MGALib;
using CoreLib;

namespace GME.CSharp.MyInterpreter
{
    [Guid(ComponentConfig.guid),
    ProgId(ComponentConfig.progID),
    ClassInterface(ClassInterfaceType.AutoDual)]
    [ComVisible(true)]
    public class MyInterpreter : IMgaComponentEx, IGMEVersionInfo
    {
		public void Main(MgaProject project, MgaFCO currentobj, MgaFCOs selectedobjs, int param)
        {
            IGMEOLEApp gme = null;
            try
            {
                gme = (IGMEOLEApp)project.GetClientByName("GME.Application").OLEServer;

                gme.ConsoleMessage("Interpreting...", msgtype_enum.MSG_INFO);


                MgaGateway.project = project;
                project.CreateTerritoryWithoutSink(out MgaGateway.territory);
				
				// TODO: Your interpreting code comes here

            }
            catch(Exception e) 
            {
                MessageBox.Show(e.Message);
            }
           
        }

        #region IMgaComponentEx Members

        public void InvokeEx(MgaProject project, MgaFCO currentobj, MgaFCOs selectedobjs, int param)
        {
            try
            {
                Main(project, currentobj, selectedobjs, param);
            }
            finally
            {
                project = null;
                currentobj = null;
                selectedobjs = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        public string ComponentName
        {
            get { return GetType().Name; }
        }

        public string ComponentProgID
        {
            get
            {
                RegistrationServices regService = new RegistrationServices();
                return regService.GetProgIdForType(GetType());
            }
        }

        public componenttype_enum ComponentType
        {
            get { return componenttype_enum.COMPONENTTYPE_INTERPRETER; }
        }

        public void Enable(bool newval)
        {
        }

        public void Initialize(MgaProject p)
        {
        }

        protected bool interactiveMode = false;
        public bool InteractiveMode
        {
            get
            {
                return interactiveMode;
            }
            set
            {
                interactiveMode = value;
            }
        }

        public void Invoke(MgaProject Project, MgaFCOs selectedobjs, int param)
        {
            InvokeEx(Project, null, selectedobjs, 0);
        }

        public void ObjectsInvokeEx(MgaProject Project, MgaObject currentobj, MgaObjects selectedobjs, int param)
        {
            throw new NotImplementedException();
        }

        public string Paradigm
        {
            get { return ComponentConfig.paradigmName; }
        }

        public object get_ComponentParameter(string Name)
        {
            if (Name == "type")
                return "csharp";

            if (Name == "path")
                return GetType().Assembly.Location;

            if (Name == "fullname")
                return GetType().FullName;

            return null;
        }

        public void set_ComponentParameter(string Name, object pVal)
        {
        }

        #endregion

        #region IMgaVersionInfo Members

        public GMEInterfaceVersion_enum version
        {
            get { return GMEInterfaceVersion_enum.GMEInterfaceVersion_Current; }
        }

        #endregion
    
        [ComRegisterFunctionAttribute]
        public static void GMERegister(Type t)
        {
            Registrar.RegisterComponentsInGMERegistry();
          
        }

        [ComUnregisterFunctionAttribute]
        public static void GMEUnRegister(Type t)
        {
            Registrar.UnregisterComponentsInGMERegistry();
        }
    }
}
