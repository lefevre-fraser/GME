﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GME.CSharp
{
    /// <summary>
    /// Automatically redirects console messages to the GME console output, if GME is available.
    /// Otherwise prints the output to System console.
    /// </summary>
    static class GMEConsole
    {        
        /// <summary>
        /// Handles error messages
        /// </summary>
        public class Error
        {
            /// <summary>
            /// Prints message to GME/system error console
            /// </summary>
            /// <param name="error">The message to be written. GME Console does not handle special characters and trims white-spaces.</param>
            public static void WriteLine(string error)
            {
                if (gme != null)
                    gme.ConsoleMessage(error, GmeLib.msgtype_enum.MSG_ERROR);
                else
                    System.Console.Error.WriteLine(error);
            }
        }

        /// <summary>
        /// Prints message to GME/system console
        /// </summary>
        /// <param name="message">The message to be written. GME Console does not handle special characters and trims white-spaces.</param>
        public static void WriteLine(string message)
        {
            if (gme != null)
                gme.ConsoleMessage(message, GmeLib.msgtype_enum.MSG_NORMAL);
            else
                System.Console.WriteLine(message);
        }
        
        /// <summary>
        /// Clear the console
        /// </summary>
        public static void Clear()
        {
            if (gme != null)
                gme.ConsoleClear();
            else
                System.Console.Clear();
        }

        /// <summary>
        /// The GME application variable
        /// </summary>
        static public GmeLib.IGMEOLEApp gme = null;
    }
}
