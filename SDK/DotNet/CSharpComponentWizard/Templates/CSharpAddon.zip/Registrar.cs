﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using MGAUTILLib;
using Microsoft.Win32;

namespace GME.CSharp
{
    [ComVisible(false)]
    public class RegistrationException : ApplicationException
    {
        public RegistrationException(string message):base(message){}
    }

    [ComVisible(false)]
    public class Registrar
    {
       
        public Registrar()
        {
        }


        public static void RegisterComponentsInGMERegistry()
        {
            try
            {

                MGAUTILLib.MgaRegistrar registrar = new MGAUTILLib.MgaRegistrar();
                if ((int)GmeLib.MgaInterfaceVersion_enum.MgaInterfaceVersion_Current != (int)((GmeLib.IMgaVersionInfo)registrar).Version)
                {
                    throw new RegistrationException("MgaInterfaceVersion mismatch: this assembly is using " +
                        (int)GmeLib.MgaInterfaceVersion_enum.MgaInterfaceVersion_Current +
                        " but the GME interface version is " + (int)((GmeLib.IMgaVersionInfo)registrar).Version +
                        "\n\nPlease install a compatible GME version or update the interop dlls.");
                }


             
                registrar.RegisterComponent(ComponentConfig.progID, ComponentConfig.componentType, ComponentConfig.componentName, ComponentConfig.registrationMode);
              
                if (!ComponentConfig.paradigmName.Equals("*"))
                {
                    registrar.Associate(
                       ComponentConfig.progID,
                        ComponentConfig.paradigmName,
                        ComponentConfig.registrationMode);
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }

        }


        public static void UnregisterComponentsInGMERegistry()
        {
            try
            {

                MGAUTILLib.MgaRegistrar registrar = new MGAUTILLib.MgaRegistrar();
                if ((int)GmeLib.MgaInterfaceVersion_enum.MgaInterfaceVersion_Current != (int)((GmeLib.IMgaVersionInfo)registrar).Version)
                {
                    throw new RegistrationException("MgaInterfaceVersion mismatch: this assembly is using " +
                        (int)GmeLib.MgaInterfaceVersion_enum.MgaInterfaceVersion_Current +
                        " but the GME interface version is " + (int)((GmeLib.IMgaVersionInfo)registrar).Version +
                        "\n\nPlease install a compatible GME version or update the interop dlls.");
                }

                registrar.UnregisterComponent(ComponentConfig.progID, ComponentConfig.registrationMode);

            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }

        }
    }
}
